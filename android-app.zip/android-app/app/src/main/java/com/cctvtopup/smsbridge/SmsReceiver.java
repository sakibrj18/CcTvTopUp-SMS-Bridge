package com.cctvtopup.smsbridge;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SmsReceiver extends BroadcastReceiver {
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;

        SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (messages == null || messages.length == 0) return;

        StringBuilder body = new StringBuilder();
        String sender = messages[0].getOriginatingAddress();
        long smsTimestamp = messages[0].getTimestampMillis();
        for (SmsMessage msg : messages) body.append(msg.getMessageBody());

        String rawSms = body.toString().trim();
        String senderAddress = sender == null ? "" : sender.trim();
        String lowerBody = rawSms.toLowerCase(Locale.US);
        String lowerSender = senderAddress.toLowerCase(Locale.US);

        // Privacy-first: ignore unrelated personal SMS.
        // bKash may appear as an alphanumeric sender ID, while message body usually contains TrxID/bKash wording.
        boolean looksBkash = lowerSender.contains("bkash") || lowerBody.contains("bkash") || lowerBody.contains("trxid") || lowerBody.contains("trx id");
        if (!looksBkash) return;

        if (!ConfigStore.isConfigured(context)) {
            ConfigStore.setLastSms(context, "bKash-like SMS received but bridge is not configured.");
            return;
        }

        final PendingResult pending = goAsync();
        final Context app = context.getApplicationContext();

        EXEC.execute(() -> {
            try {
                String dedupHash = Crypto.sha256Hex(senderAddress + "|" + smsTimestamp + "|" + rawSms);
                if (ConfigStore.isDuplicateSms(app, dedupHash, System.currentTimeMillis())) return;

                JSONObject payload = new JSONObject();
                payload.put("raw_sms", rawSms);
                payload.put("sender_address", senderAddress);
                payload.put("sms_time", isoUtc(smsTimestamp));
                payload.put("app_version", "1.0.0");

                ConfigStore.setLastSms(app, "Received at " + displayTime(smsTimestamp) + " from " + senderAddress);
                ApiClient.Result result = ApiClient.postSigned(app, "receiver.php", payload);
                String stamp = displayTime(System.currentTimeMillis());
                ConfigStore.setLastSync(app, stamp + " — " + (result.ok ? "Synced" : "Not synced") + " — " + result.message);
            } catch (Exception e) {
                ConfigStore.setLastSync(app, "Error: " + e.getMessage());
            } finally {
                pending.finish();
            }
        });
    }

    private static String isoUtc(long ms) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(ms));
    }

    private static String displayTime(long ms) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(ms));
    }
}
