package com.cctvtopup.smsbridge;

import android.content.Context;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class ApiClient {

    public static class Result {
        public final boolean ok;
        public final int httpCode;
        public final String body;
        public final String message;
        public Result(boolean ok, int httpCode, String body, String message) {
            this.ok = ok; this.httpCode = httpCode; this.body = body; this.message = message;
        }
    }

    public static Result postSigned(Context context, String endpoint, JSONObject json) {
        if (!ConfigStore.isConfigured(context)) return new Result(false, 0, "", "Bridge is not configured.");
        String base = ConfigStore.serverUrl(context);
        if (!base.startsWith("https://")) return new Result(false, 0, "", "HTTPS is required.");

        HttpURLConnection conn = null;
        try {
            String raw = json.toString();
            String timestamp = String.valueOf(System.currentTimeMillis() / 1000L);
            String nonce = UUID.randomUUID().toString().replace("-", "") + Long.toHexString(System.nanoTime());
            String signed = timestamp + "\n" + nonce + "\n" + raw;
            String signature = Crypto.hmacSha256Hex(ConfigStore.secret(context), signed);

            URL url = new URL(base + "/" + endpoint);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("X-MFS-Device-ID", ConfigStore.deviceId(context));
            conn.setRequestProperty("X-MFS-Timestamp", timestamp);
            conn.setRequestProperty("X-MFS-Nonce", nonce);
            conn.setRequestProperty("X-MFS-Signature", signature);

            byte[] bytes = raw.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }

            int code = conn.getResponseCode();
            InputStream is = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
            String body = readAll(is);
            String message = "HTTP " + code;
            try {
                JSONObject resp = new JSONObject(body);
                message = resp.optString("message", message);
            } catch (Exception ignored) {}
            return new Result(code >= 200 && code < 300, code, body, message);
        } catch (Exception e) {
            return new Result(false, 0, "", e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }
}
