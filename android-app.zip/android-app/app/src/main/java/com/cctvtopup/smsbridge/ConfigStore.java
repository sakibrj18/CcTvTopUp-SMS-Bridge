package com.cctvtopup.smsbridge;

import android.content.Context;
import android.content.SharedPreferences;

public class ConfigStore {
    private static final String PREFS = "cctv_mfs_bridge";

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void saveConfig(Context c, String serverUrl, String deviceId, String secret) {
        prefs(c).edit()
                .putString("server_url", normalizeBase(serverUrl))
                .putString("device_id", deviceId.trim())
                .putString("secret", secret.trim())
                .apply();
    }

    public static String serverUrl(Context c) {
        return prefs(c).getString("server_url", "https://cctvtopup.com/api/mfs");
    }

    public static String deviceId(Context c) {
        return prefs(c).getString("device_id", "");
    }

    public static String secret(Context c) {
        return prefs(c).getString("secret", "");
    }

    public static boolean isConfigured(Context c) {
        return !deviceId(c).isEmpty() && !secret(c).isEmpty() && serverUrl(c).startsWith("https://");
    }

    public static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    public static void setLastSms(Context c, String value) {
        prefs(c).edit().putString("last_sms", value).apply();
    }

    public static String lastSms(Context c) {
        return prefs(c).getString("last_sms", "none");
    }

    public static void setLastSync(Context c, String value) {
        prefs(c).edit().putString("last_sync", value).apply();
    }

    public static String lastSync(Context c) {
        return prefs(c).getString("last_sync", "none");
    }

    public static boolean isDuplicateSms(Context c, String hash, long now) {
        SharedPreferences p = prefs(c);
        String oldHash = p.getString("last_sms_hash", "");
        long oldTime = p.getLong("last_sms_hash_time", 0L);
        if (hash.equals(oldHash) && (now - oldTime) < 10 * 60 * 1000L) return true;
        p.edit().putString("last_sms_hash", hash).putLong("last_sms_hash_time", now).apply();
        return false;
    }
}
