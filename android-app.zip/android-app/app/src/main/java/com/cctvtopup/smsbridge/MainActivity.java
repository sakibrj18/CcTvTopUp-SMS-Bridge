package com.cctvtopup.smsbridge;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int SMS_PERMISSION = 1001;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    private EditText serverUrl, deviceId, secret;
    private TextView statusBox, lastSms, lastSync;
    private Button saveBtn, testBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverUrl = findViewById(R.id.serverUrl);
        deviceId = findViewById(R.id.deviceId);
        secret = findViewById(R.id.secret);
        statusBox = findViewById(R.id.statusBox);
        lastSms = findViewById(R.id.lastSms);
        lastSync = findViewById(R.id.lastSync);
        saveBtn = findViewById(R.id.saveBtn);
        testBtn = findViewById(R.id.testBtn);

        serverUrl.setText(ConfigStore.serverUrl(this));
        deviceId.setText(ConfigStore.deviceId(this));
        secret.setText(ConfigStore.secret(this));
        secret.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        saveBtn.setOnClickListener(v -> saveConfig());
        testBtn.setOnClickListener(v -> testConnection());

        ensureSmsPermission();
        refreshUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
    }

    private void ensureSmsPermission() {
        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS}, SMS_PERMISSION);
        }
    }

    private void saveConfig() {
        String url = ConfigStore.normalizeBase(serverUrl.getText().toString());
        String id = deviceId.getText().toString().trim();
        String sec = secret.getText().toString().trim();
        if (!url.startsWith("https://")) {
            toast("Server URL must use HTTPS.");
            return;
        }
        if (id.isEmpty() || sec.length() < 32) {
            toast("Enter the Device ID and full signing secret from Phase 1.");
            return;
        }
        ConfigStore.saveConfig(this, url, id, sec);
        toast("Connection saved.");
        refreshUi();
    }

    private void testConnection() {
        saveConfig();
        if (!ConfigStore.isConfigured(this)) return;
        testBtn.setEnabled(false);
        statusBox.setText("Testing secure server connection...");
        statusBox.setTextColor(Color.parseColor("#FBBF24"));

        exec.execute(() -> {
            try {
                JSONObject payload = new JSONObject();
                payload.put("action", "ping");
                payload.put("app_version", "1.0.0");
                ApiClient.Result result = ApiClient.postSigned(this, "status.php", payload);
                runOnUiThread(() -> {
                    testBtn.setEnabled(true);
                    if (result.ok) {
                        statusBox.setText("CONNECTED — Secure signed connection verified");
                        statusBox.setTextColor(Color.parseColor("#86EFAC"));
                        ConfigStore.setLastSync(this, "Server test successful");
                    } else {
                        statusBox.setText("NOT CONNECTED — " + result.message);
                        statusBox.setTextColor(Color.parseColor("#FCA5A5"));
                    }
                    refreshActivityText();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    testBtn.setEnabled(true);
                    statusBox.setText("NOT CONNECTED — " + e.getMessage());
                    statusBox.setTextColor(Color.parseColor("#FCA5A5"));
                });
            }
        });
    }

    private void refreshUi() {
        if (ConfigStore.isConfigured(this)) {
            if (!statusBox.getText().toString().startsWith("CONNECTED")) {
                statusBox.setText("Configured — tap Test Server Connection");
                statusBox.setTextColor(Color.parseColor("#FBBF24"));
            }
        } else {
            statusBox.setText("Not configured — add Device ID + Signing Secret");
            statusBox.setTextColor(Color.parseColor("#FCA5A5"));
        }
        refreshActivityText();
    }

    private void refreshActivityText() {
        lastSms.setText("Last bKash SMS: " + ConfigStore.lastSms(this));
        lastSync.setText("Last server sync: " + ConfigStore.lastSync(this));
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION && (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "SMS permission is required for instant bKash verification.", Toast.LENGTH_LONG).show();
        }
    }
}
